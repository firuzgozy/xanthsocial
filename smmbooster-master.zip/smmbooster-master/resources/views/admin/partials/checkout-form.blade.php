
<div class="col-md-12">
    <div class="row">
        <form class="w-100 form-group" action="/checkout" method="post" id="payment-form">
            <div class="form-row">
                <label for="card-element">Credit or debit card</label>
               <div id="card-element"></div>
               <div id="card-errors" role="alert"></div>
            </div>
         </form>
    </div>
</div>
